#ifndef _LENA512_H
#define _LENA512_H

extern unsigned char imageLena512[];

#endif

