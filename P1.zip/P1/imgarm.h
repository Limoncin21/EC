#ifndef _IMGARM_H_
#define _IMGARM_H_

int gaussian(unsigned char* im1, int width, int height, int i, int j);
int sobel(unsigned char* im1, int width, int height, int i, int j);

#endif

